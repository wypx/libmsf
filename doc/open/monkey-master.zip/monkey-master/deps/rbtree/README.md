[Taken from: https://github.com/pvachon/rbtree]

A simple, intrusive, zero-allocation Red-Black tree implementation.

Designed exclusively for systems where determinism is needed.

Licensed under a 2-clause BSD license for the sake of simplicity.
